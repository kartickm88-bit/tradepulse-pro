import express from "express";
import cors from "cors";
import dotenv from "dotenv";
dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 8080;

// Phase-1 API contract for the TradePulse Pro frontend.
// Live Angel One SmartAPI connection is intentionally isolated here so
// credentials never reach the client application.

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, service: "TradePulse Pro", mode: "prototype" });
});

app.get("/api/market/summary", (_req, res) => {
  res.json({
    nifty: { ltp: 25153.60, changePct: -0.34 },
    bankNifty: { ltp: 51278.30, changePct: 0.38 },
    finNifty: { ltp: 23511.80, changePct: 0.35 },
    vix: { ltp: 13.24, changePct: -1.34 },
    note: "Prototype data — replace with SmartAPI feed."
  });
});

app.post("/api/scanner/run", (req, res) => {
  const conditions = req.body?.conditions || [];
  res.json({
    status: "ok",
    conditions,
    matches: [
      { symbol: "TATAMOTORS", signal: "BUY", strength: 82 },
      { symbol: "RELIANCE", signal: "BUY", strength: 78 },
      { symbol: "HDFCBANK", signal: "BUY", strength: 76 }
    ],
    note: "Prototype results — connect live market feed before trading."
  });
});

app.get("/api/signals", (_req, res) => {
  res.json([
    { symbol: "TATAMOTORS", type: "INTRADAY", signal: "BUY", strength: 82 },
    { symbol: "RELIANCE", type: "SWING", signal: "BUY", strength: 78 },
    { symbol: "NIFTY", type: "INDEX", signal: "BUY", strength: 76 }
  ]);
});

app.listen(PORT, () => {
  console.log(`TradePulse Pro backend running on http://localhost:${PORT}`);
});
