# TradePulse Pro — Backend V1

This is the first backend scaffold for the V3 trading-terminal UI.

## Architecture

Android/Web App
        ↓
TradePulse API
        ↓
Market-data adapter
        ↓
Angel One SmartAPI
        ↓
NSE/BSE/NFO live + historical data

## Planned live modules

- WebSocket market feed
- NIFTY / BANK NIFTY / FINNIFTY
- F&O stock universe
- OHLC + volume + OI
- Historical candles
- RSI / EMA / VWAP calculations
- Breakout / breakdown scanner
- Aggressive buyer/seller logic
- OI buildup: long buildup, short buildup, short covering, long unwinding
- Option Greeks
- Alerts
- Watchlist

## Safety

This scaffold does NOT place orders. It is a market-analysis/signals backend.
API credentials must remain server-side.

## Run

1. Install Node.js
2. Copy `.env.example` to `.env`
3. Add your broker credentials when the live adapter is implemented
4. Run `npm install`
5. Run `npm start`

The current endpoints return prototype data until the live SmartAPI adapter is connected.
